import React from 'react';
import Weather from './components/Weather.jsx';
import './App.css';

function App() {
  return (
   <Weather/>
    
  );
}

export default App;
